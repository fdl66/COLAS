gcc -g -DDEBUG -fPIC -o ${1} ${1}.c -DASLIBRARY  -lm -LZMQ/zmqlibs -lzmq  -LZMQ/czmqlibs -lczmq -Wimplicit-function-declaration -Wall
